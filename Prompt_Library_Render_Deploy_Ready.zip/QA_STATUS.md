# V2-C Public AI Migration — Controlled QA

Date: October 11, 2026

## User acceptance criteria
1. Public, non-Vercel, visitor-login-free link.
2. Live model-authored prompt generation (not concatenation).
3. Full guided journey and final independent AI refinement.
4. Prior V2-B remains unchanged.

## Implemented
- Portable Node 22 app compatible with Render, retaining the V2-C browser experience.
- Server-side Groq Chat Completions model connection using `openai/gpt-oss-120b` (configurable via AI_MODEL).
- Two model calls during final refinement, structured JSON output, no fake fallback.
- Server-side key only, same-origin restriction, request-size validation, basic per-instance quotas, provider errors surfaced.
- Build manifest, deploy instructions, platform blueprint.

## Tested
- Node model-path tests: 4/4 PASS using an upstream test double; includes two-stage refinement.
- Browser UI: desktop 1440, mobile 390, narrow mobile 320 — PASS with simulated model output.
- Local health endpoint responds 200; missing credential returns explicit 503.

## NOT VERIFIED / NOT LOCKED
- Actual Groq model request (no secure provider credential is currently configured).
- Render public deployment (user must confirm Render workspace; deployment source needs accessible Git repo URL).
- Real-world abuse/spend protection under public traffic (memory quota only; set provider limits / durable quota for broad sharing).
- Provider response quality on real user examples (Arabic and English), failure handling under real latency.

## Next external steps
1. User confirms Render workspace `My Workspace` (listed workspace ID `tea-db5o6h67bikc73dgej0g`).
2. Set up Render Git source. No matching accessible repository exists in connected GitHub; create a repository through GitHub UI or supply a cloneable repository URL.
3. Enter GROQ_API_KEY directly in Render's environment settings; do not paste it in chat or browser.
4. Set provider-side budget / rate limits and perform real model smoke/QA before declaring complete.

No Vercel deployment or protected preview has been changed in this migration attempt.
