# Executive AI Playbook — public AI build (non-Vercel)

The existing V2-C browser app is served by a small Node server with a real Groq Chat Completions integration. The public website requires **no visitor login**. Prompts are synthesized by a language model, not concatenated from templates. The key stays in the server's environment.

## Deploy to Render

1. Connect Render in ChatGPT or your Render account, then publish this directory from a Git repository as a **Web Service** (Node 22); `render.yaml` is included for a Blueprint.
2. In Render's service environment settings, add the secret `GROQ_API_KEY` from the Groq console. **Never put an API key in the website, Git repository, browser, or ChatGPT message.**
3. Deploy the service and open its public `https://<service>.onrender.com` URL. Users do not need an account.
4. Check `GET /api/health` for `aiConfigured: true`. Run a real end-to-end prompt generation and verify the model-generated result and final refinement before approving the website.
5. Enforce a provider-side usage cap/spending limit. The included in-memory per-IP and global throttles are appropriate for a limited single-instance review only: they reset on restart and aren't durable.

Groq's free limits and Render's free-hosting limits apply. Render's free web services may sleep after inactivity and take time to wake up. For reliable distribution and sensitive information, use a durable rate-limit service, abuse controls, and suitable data-governance review.

### Environment

- `GROQ_API_KEY` (required): Server-side secret (never expose to client)
- `AI_MODEL`: `openai/gpt-oss-120b` by default
- `DAILY_TOTAL_LIMIT`: default 60 (per-process)
- `HOURLY_IP_LIMIT`: default 8 (per-process, per IP)
- `PORT`: supplied by Render

### Local smoke

`npm start` then visit `http://localhost:10000`. Without the key, UI loads but AI endpoint truthfully reports unavailable.

No Vercel SDK, domain, routing, or OIDC is required.
