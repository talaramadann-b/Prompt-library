'use strict';
const http=require('node:http');
const fs=require('node:fs');
const path=require('node:path');
const {input,refine}=require('./api/core');
const HTML=fs.readFileSync(path.join(__dirname,'index.html'));
const MAX_BODY=28000;
const port=Number(process.env.PORT||10000);
// Controlled public pilot quotas. In-memory counters reset on process restart;
// use provider-side hard limits and durable quota before any broad public release.
const hourByIP=new Map(),dayByIP=new Map();let day=0,dayCount=0;
function today(){return Math.floor(Date.now()/86400000)}
function clientIP(req){
  const raw=String(req.headers['x-forwarded-for']||req.socket.remoteAddress||'unknown');
  return raw.split(',')[0].trim().slice(0,65);
}
function quota(req){
  const t=Date.now(),ip=clientIP(req);const currentDay=today();
  if(day!==currentDay){day=currentDay;dayCount=0;dayByIP.clear();}
  const allLimit=Math.max(1,Math.min(Number(process.env.DAILY_TOTAL_LIMIT||60),1000));
  const hourLimit=Math.max(1,Math.min(Number(process.env.HOURLY_IP_LIMIT||8),100));
  const prev=hourByIP.get(ip)||{since:t,n:0};
  if(t-prev.since>=3600000){prev.since=t;prev.n=0;}
  if(prev.n>=hourLimit||dayCount>=allLimit)return false;
  prev.n++;dayCount++;hourByIP.set(ip,prev);
  if(hourByIP.size>2000)hourByIP.clear();
  return true;
}
function respond(res,code,body,headers={}){
 res.writeHead(code,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer',...headers});
 res.end(JSON.stringify(body));
}
function validOrigin(req){
 const origin=req.headers.origin; if(!origin)return true;
 const host=String(req.headers.host||'');
 // Local dev or the current HTTPS public hostname; no third-party browser calls.
 return origin===`https://${host}`||origin===`http://${host}`;
}
const server=http.createServer(async(req,res)=>{
 const url=(req.url||'').split('?')[0];
 if(req.method==='GET'&&(url==='/'||url==='/index.html')){
  res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-cache','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','Content-Security-Policy':"default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; base-uri 'none'; object-src 'none'; frame-ancestors 'none'"});
  res.end(HTML);return;
 }
 if(req.method==='GET'&&url==='/api/health'){
  return respond(res,200,{status:'ok',provider:'groq',aiConfigured:Boolean(process.env.GROQ_API_KEY),model:process.env.AI_MODEL||'openai/gpt-oss-120b',deployment:'public-host-portable'});
 }
 if(url!=='/api/refine')return respond(res,404,{error:'Not found'});
 if(req.method!=='POST')return respond(res,405,{error:'POST only'});
 if(req.headers['x-playbook-request']!=='refine'||!validOrigin(req))return respond(res,403,{error:'Request not accepted'});
 if(!process.env.GROQ_API_KEY)return respond(res,503,{error:'AI refinement is not yet activated on this website.'});
 if(!quota(req))return respond(res,429,{error:'Usage limit reached for this public pilot.'});
 const len=Number(req.headers['content-length']||0);if(len>MAX_BODY)return respond(res,413,{error:'Brief is too large'});
 let size=0,buffers=[];
 try{
  for await(const chunk of req){size+=chunk.length;if(size>MAX_BODY)throw Object.assign(new Error('Body exceeds size limit'),{status:413});buffers.push(chunk);}
  let raw=Buffer.concat(buffers).toString('utf8');let payload=input(JSON.parse(raw));
  const answer=await refine(payload);
  return respond(res,200,answer);
 }catch(e){
  const msg=String(e?.message||'AI service unavailable');
  const status=e.status||(/required|Invalid|brief too long/i.test(msg)?400:/rate limit|Usage limit/.test(msg)?429:/not configured|authentication|account access/i.test(msg)?503:502);
  return respond(res,status,{error:status===502?'Live AI refinement failed. No template fallback was substituted.':msg.slice(0,180)});
 }
});
server.listen(port,'0.0.0.0',()=>console.log('Playbook listening on',port));
